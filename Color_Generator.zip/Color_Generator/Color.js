const btn1=document.querySelector("#Btn1");
const Container=document.querySelector("#Color-Container");
const name1=document.querySelector("#bold");

btn1.addEventListener('click',()=>{
    const array1=[];
    for(i=0;i<3;i++){
        x=Math.floor((Math.random()*255));
        array1.push(x);
    }   
    Container.style.backgroundColor=`rgb(${array1[0]},${array1[1]},${array1[2]})`;
    name1.innerText=`rgb(${array1[0]},${array1[1]},${array1[2]})`;
})


// Container.style.backgroundColor=rgb(array1[0],array1[1],array1[2];

    
